# 产品盲测技能官网 - 需求拆解文档

## 产品概述

- **产品类型**: 落地页/官网展示站
- **场景类型**: <scene_type>prototype-app</scene_type>
- **目标用户**: 产品负责人、创业者、研发团队（关注产品留存与转化优化）
- **核心价值**: 通过系统化“产品失败地图”构建，提前发现致命体验断点，降低流失并提升转化
- **界面语言**: 中文
- **主题偏好**: 浅色（背景 #F8FAFC，主色 #2563EB，强调色 #10B981）
- **导航模式**: 锚点导航 `#anchor`
- **导航布局**: Topbar（顶部固定）

---

## 页面结构总览

> **说明**：此表为页面生成的唯一数据源，采用单页锚点滚动布局，区块间距 48px，内容内间距 24px，圆角 8px

**页面文件**: `HomePage.tsx`

| 区块名称 | 锚点 | 区块说明 |
|---------|------|---------|
| 首屏英雄区 | `#hero` | 展示产品定位“构建产品失败地图”、核心痛点与CTA按钮，全屏通栏吸引注意力 |
| 功能展示区 | `#features` | 4大核心能力卡片网格（多维角色/极端样本/失败地图/对抗测试），清晰传递方法论 |
| 案例展示区 | `#cases` | 展示落地成果数据与客户证言，增强可信度与转化说服力 |
| 联系咨询区 | `#contact` | 合作咨询表单（姓名/公司/邮箱/需求），收集高意向线索 |

---

## 导航配置

> **说明**：此表为导航生成的数据源，锚点需与页面结构总览一致

- **导航布局**: Topbar（顶部固定，滚动后背景实色化）
- **导航项**:
  | 导航文字 | 锚点 |
  |---------|------|
  | 首页 | `#hero` |
  | 核心能力 | `#features` |
  | 客户案例 | `#cases` |
  | 合作咨询 | `#contact` |

---

## 功能列表

> **说明**：每个区块的功能点，供页面生成使用

- **页面/区块**: 首屏英雄区 (`#hero`)
  - **页面目标**: 3秒内传递核心价值，制造痛点共鸣，引导访客向下滚动或点击咨询
  - **功能点**:
    - **主视觉与标题展示**: 居中排版“产品盲测技能”主标题 + “你缺的不是测试，是系统性证明产品会死在哪里的方法”副标题
    - **核心痛点高亮区**: 动态展示“用户留不住/转化低/反馈少/优化无改善”等典型场景文案，强化共鸣
    - **双CTA按钮组**: “立即获取测评报告”（主按钮，锚点跳转至 `#contact`）与“了解工作原理”（次按钮，平滑滚动至 `#features`）

- **页面/区块**: 功能展示区 (`#features`)
  - **页面目标**: 结构化呈现四步方法论，将抽象概念转化为可视化的能力卡片
  - **功能点**:
    - **四步法卡片网格**: 2x2 响应式卡片布局，分别对应“多维角色模拟”、“极端样本优先”、“失败地图构建”、“对抗测试机制”
    - **能力详情悬停交互**: 鼠标悬停卡片时，展开显示具体维度（如职业/年龄/认知组合、Drop-off Peak/Misunderstanding Zone/Rage Point等）
    - **传统测试 vs 盲测对比条**: 横向对比组件，左侧列出传统测试缺陷（找熟人/看功能/出问题再修），右侧高亮本技能优势（提前发现/降低流失/提升转化）

- **页面/区块**: 案例展示区 (`#cases`)
  - **页面目标**: 用真实数据与成果背书，消除决策顾虑
  - **功能点**:
    - **核心指标数据卡片**: 3-4个关键数据展示（如“流失率降低 40%”、“上线前拦截 12 个致命断点”、“转化率提升 25%”），使用强调色 #10B981 高亮数值
    - **客户证言网格**: 展示合作企业标识与简短评价（预留占位结构，支持后续替换真实数据）
    - **优化前后路径对比图**: 简化的“优化前 vs 优化后”用户流失路径示意图，直观体现价值

- **页面/区块**: 联系咨询区 (`#contact`)
  - **页面目标**: 降低填写门槛，高效收集合作意向信息
  - **功能点**:
    - **极简咨询表单**: 包含“姓名”、“公司/产品名”、“联系邮箱”、“当前核心痛点（下拉/文本）”四个字段
    - **表单提交与状态反馈**: 提交按钮加载态，成功后显示“已收到您的需求，24小时内发送定制测评方案”提示
    - **隐私合规提示**: 表单底部添加“信息仅用于合作咨询，严格保密”小字声明，提升信任感

---

## 数据共享配置

[无跨页面数据共享需求，省略]

-------

# UI 设计指南

> **场景类型**: <scene_type>prototype-app</scene_type>（应用架构设计）
> **确认检查**: 本指南适用于可交互的应用/网站/工具。如果产出物是静态报告或带进度的教程，请使用对应场景的模板。

> ℹ️ Section 1-2 为设计意图与决策上下文。Code agent 实现时以 Section 3 及之后的具体参数为准。

## 1. Design Archetype (设计原型)

### 1.1 内容理解
- **目标用户**: 产品负责人、创业者、研发团队。心理预期：焦虑于用户流失与转化瓶颈，寻求系统化、可验证的解决方案。
- **核心目的**: 清晰传递“构建产品失败地图”的核心价值，建立专业信任感，引导访客提交合作咨询。
- **期望情绪**: 理性、清晰、专业、掌控感。
- **需避免的感受**: 廉价营销感、信息过载、过度装饰导致的注意力分散。

### 1.2 设计语言
- **Aesthetic Direction**: 极简科技风（Minimalist Tech）。借鉴 OpenAI/Anthropic 的克制与留白，以清晰的排版层级和精准的色块引导视线，强调“系统化”与“数据驱动”的理性气质。
- **Visual Signature**: 
  1. 大面积 `#F8FAFC` 浅灰蓝背景与纯白卡片的微妙层次
  2. `8px` 统一圆角塑造现代、克制的几何感
  3. 主色蓝 `#2563EB` 严格用于行动点，辅助紫 `#8B5CF6` 仅用于方法论区块的视觉锚点
- **Emotional Tone**: 冷静、高效、可信赖。用留白代替装饰，用数据代替口号。
- **Design Style**: `Muji 极简` × `Rounded 圆润几何` — 落地页需清晰的信息层级与亲和力，极细边框/无阴影卡片 + `8px` 统一圆角 + 充裕留白。
- **Application Type**: Landing Site（单页锚点滚动，Topbar 导航）

## 2. Design Principles (设计理念)
1. **内容即界面**：不依赖复杂图形，依靠字重对比、间距节奏和精准的色彩语义传递信息。
2. **行动点唯一性**：页面中仅保留一个核心 CTA（立即获取测评报告），次级操作降级为文字链或幽灵按钮，避免决策疲劳。
3. **理性可视化**：方法论与案例数据使用结构化卡片与对比组件呈现，避免抽象插画，强化“可验证、可量化”的产品调性。
4. **呼吸感优先**：严格遵循 `48px` 区块间距与 `24px` 内容内边距，确保信息在移动端与桌面端均有充足的阅读缓冲。

## 3. Color System (色彩系统)

> 基于用户指定色值与产品定位自主推导完整色板。确保整体协调且符合无障碍对比度标准。
> **⚠️ App 场景配色规则**：App 子场景**禁止使用**共用预设配色方案库中的 7 个方案。本系统基于用户提供的品牌色自主设计。

**配色设计理由**：以 `#2563EB` 建立专业信任与行动指引，`#8B5CF6` 作为功能区块的理性强调，`#10B981` 专用于正向数据高亮。整体采用低饱和度冷灰背景降低视觉噪音，突出核心内容。

### 3.1 主题颜色

| 角色 | CSS 变量 | Tailwind Class | HSL 值 | 设计说明 |
|-----|---------|----------------|--------|---------|
| bg | `--background` | `bg-background` | `hsl(210 40% 98%)` | 浅灰蓝页面背景，减少纯白刺眼感 |
| surface | `--card` | `bg-card` | `hsl(0 0% 100%)` | 纯白卡片/表单背景，形成微层次 |
| text | `--foreground` | `text-foreground` | `hsl(222 47% 11%)` | 深 slate 主文字，高对比度易读 |
| textMuted | `--muted-foreground` | `text-muted-foreground` | `hsl(215 16% 47%)` | 次要说明、标签、占位符文字 |
| primary | `--primary` | `bg-primary` | `hsl(221 83% 53%)` | 主交互色（CTA、品牌标识、链接） |
| primary-foreground | `--primary-foreground` | `text-primary-foreground` | `hsl(0 0% 100%)` | 主按钮内文字/图标色 |
| accent | `--accent` | `bg-accent` | `hsl(221 83% 96%)` | 次级交互反馈（hover/focus/骨架屏背景） |
| accent-foreground | `--accent-foreground` | `text-accent-foreground` | `hsl(221 83% 53%)` | accent 区域上的文字/图标色 |
| border | `--border` | `border-border` | `hsl(214 32% 91%)` | 卡片/输入框/分割线边框 |
| highlight | `--highlight` | `text-highlight` | `hsl(160 84% 39%)` | 语义强调色（数据高亮、成功状态） |

> **Color Token 语义速查（供 code agent 参考）**:
> - `primary` → 主行动：按钮填充、激活态高亮、关键操作 CTA
> - `accent` → 状态反馈：Ghost/Outline 按钮 hover、DropdownMenu focus、Toggle 激活、Skeleton 占位背景
> - `muted` → 静态非交互：禁用态背景、次级说明背景、占位文字色（`text-muted-foreground`）
> - `highlight` → 数据高亮：案例区关键指标、成功状态标识

### 3.2.1 Topbar 颜色（仅当使用 Topbar 导航时参考）

> **重要**：shadcn/ui 没有 Topbar 组件，**不存在** `--topbar-*` 等内置 CSS 变量。

**正确做法**：
- Topbar 背景使用页面背景色 `hsl(210 40% 98%)`，滚动后添加底部边框 `border-b border-border` 以区分导航区与内容区
- 文字色使用 `text-foreground`，确保对比度 ≥ 4.5:1
- 导航项 Hover 态使用 `bg-accent` 提供轻量交互反馈

### 3.3 语义颜色（可选）

> 表单验证与提交状态使用以下衍生色：
- **成功**: `hsl(160 84% 39%)` (与 highlight 一致)
- **错误**: `hsl(0 72% 51%)` (固定语义色)

## 4. Typography (字体排版)
- **Heading**: `Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "PingFang SC", "Microsoft YaHei", sans-serif`
- **Body**: `Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "PingFang SC", "Microsoft YaHei", sans-serif`
- **字体导入**: 使用系统字体栈，无需 `@import`。优先依赖现代 OS 内置无衬线字体，确保跨端渲染一致性与加载性能。

## 5. Global Layout Structure (全局布局结构)

### 5.1 Page Content Zones (页面区块配置)

> ⚠️ **全局统一规则**：以下参数为所有页面共享的**唯一**内容区定义。禁止按页面拆分、禁止为不同页面定义不同的 max-w。

**Standard Content Zone（全页面统一）**:
- **Maximum Width**: `max-w-6xl` (1152px)
- **Padding**: `px-4 sm:px-6 lg:px-8`
- **Alignment**: `mx-auto`
- **Vertical Spacing**: 区块间 `gap-12` (48px)，区块内 `space-y-6`，保持 8px 倍数一致性

**宽内容溢出策略**：当页面内某个组件（如多列表格、甘特图）超出 Standard Content Zone 宽度时，在该组件外层使用 `overflow-x-auto` 实现横向滚动，禁止为此放大容器 max-w。

**Hero/Banner 区块**（如适用）:
- **Width**: `w-full`（仅背景可全宽，内部文字内容仍受 Standard Content Zone 的 max-w 约束）
- **Padding**: `py-16 md:py-24 lg:py-32`
- **Background**: `bg-background` (与页面背景一致，依靠排版对比建立层级)

## 6. Visual Effects & Motion (视觉效果与动效)

- **Header/Hero 视觉方案**: 无独立背景色，采用纯排版模式（Mode F）。依靠 `font-black` 标题与 `font-light` 副标题的强烈字重对比，以及 `highlight` 色数据高亮建立视觉锚点。
- **装饰手法**: 无。功能区块使用左侧 `3px` 实色边框（`border-l-4 border-primary` 或 `border-accent`）作为轻量级视觉区分，避免冗余图形。
- **圆角**: `rounded-lg` (8px) 全局统一应用于卡片、按钮、输入框、标签。
- **阴影**: `shadow-sm` 仅用于表单容器与核心数据卡片，其余区域依赖边框 `border-border` 分层。
- **复杂背景文字处理**:
  - 渐变背景: 无
  - 图片背景: 无
  - 有色背景: 按钮/标签使用 `bg-primary` + `text-primary-foreground`，对比度 > 4.5:1

### 6.1 动效意图

> 本节只声明动效意图（what / why），不提供实现细节（how）；禁止输出 `@keyframes` / cubic-bezier 字符串 / 完整 CSS 声明 / 具体实现技术选型。

- **整体动效风格**: 克制、短促、以 opacity + 微位移为主，服务于信息层级而非炫技。
- **页面入场**: 根容器以微微上移淡入，短促（约 200-300ms），避免长动画拖慢首屏感知。
- **滚动揭示**: 各 Section 随视口进入依次淡入上移，节奏「快速」，无需复杂 stagger，保持浏览连贯性。
- **列表项动效 · 变更模式**: 无（静态落地页）
- **列表项动效 · 意图**: 无
- **对话框/弹层**: 表单提交成功提示使用缩放淡入，退场更快（约 150ms），不打断阅读流。
- **关键交互微动效**: 按钮 Hover 时背景色平滑过渡至 `bg-primary/90` 并伴随 `scale-[1.02]` 微放大；卡片 Hover 时边框色加深，提供明确的交互边界反馈。

## 7. Components (组件指南)

> **必须引用 Color System 中的颜色角色**（如 `primary`、`accent`、`border`）
> 每个组件需定义 Default/Hover/Active/Focus/Disabled 状态

### Buttons
- **Primary**: 背景 `bg-primary` / 文字 `text-primary-foreground` / Hover `bg-primary/90` / Active `bg-primary/80` / Focus `ring-2 ring-primary/40 ring-offset-2` / Disabled `bg-primary/50 cursor-not-allowed`
- **Secondary (Ghost)**: 背景 `bg-transparent` / 文字 `text-foreground` / Hover `bg-accent text-accent-foreground` / Active `bg-accent/80` / Focus `ring-2 ring-border ring-offset-2`
- **Outline**: 背景 `bg-transparent` / 边框 `border border-border` / 文字 `text-foreground` / Hover `bg-accent text-accent-foreground`

### Form Elements
- **输入框**: 背景 `bg-card` / 边框 `border border-border` / Hover `border-primary/50` / Focus `border-primary ring-2 ring-primary/20 ring-offset-2` / Disabled `bg-muted/50 cursor-not-allowed`
- **Placeholder**: `text-muted-foreground`
- **Label**: `text-sm font-medium text-foreground`
- **Error Text**: `text-sm text-red-600`

### Cards
- **基础卡片**: 背景 `bg-card` / 边框 `border border-border` / 圆角 `rounded-lg` / 阴影 `shadow-sm` / 内边距 `p-6` (24px)
- **功能卡片**: 继承基础卡片，左侧添加 `border-l-4 border-l-primary` 强化区块识别

### Menu / Dropdown
- **菜单项 Focus/Hover**: `bg-accent text-accent-foreground`

### Skeleton
- **加载占位**: `bg-muted animate-pulse` / 圆角 `rounded-md`

## 8. Flexibility Note (灵活性说明)

> **一致性优先原则**：多页应用（MPA）中，所有页面必须使用相同的核心参数（最大宽度、容器边距、圆角、阴影等），确保整体设计语言统一。
>
> **允许的微调范围**（code agent 可自行判断）：
> - 响应式断点适配（如移动端边距可减小至 `px-4`，Hero 区高度可压缩）
> - 页面内部的局部间距（如卡片内边距在移动端可调整为 `p-5`）
> - 单页组件（如 Modal）的独立样式
>
> **禁止的随意变更**：
> - ❌ 不同页面/区块使用不同的最大宽度
> - ❌ 不同区块使用不同的圆角/阴影风格（严格保持 `rounded-lg`）
> - ❌ 不同页面使用不同的主色调或破坏 `48px` 区块间距节奏

## 9. Signature & Constraints (设计签名与禁区)

### DO (视觉签名)
1. **8px 圆角统一**：所有交互元素、卡片、输入框严格使用 `rounded-lg`，塑造现代、克制的几何秩序。
2. **48px 呼吸间距**：区块间固定 `gap-12` (48px)，内容内 `p-6` (24px)，确保信息在移动端与桌面端均有充足的阅读缓冲。
3. **左侧色条锚点**：功能卡片与高亮区块使用 `border-l-4` 配合 `primary` 或 `accent` 色，替代大面积色块，保持页面轻盈。
4. **数据高亮专属色**：所有正向指标、成功案例数据严格使用 `hsl(160 84% 39%)`，建立“增长/成功”的视觉条件反射。

### DON'T (禁止做法)
> 通用约束参见「通用约束」。以下为 Prototype 特有：
- ❌ 在 Hero 区使用复杂背景图或渐变遮罩，破坏极简科技风的留白节奏
- ❌ 使用超过 3 种以上的装饰色，导致视觉焦点分散（严格限制：蓝主行动、紫功能强调、绿数据高亮）
- ❌ 表单字段超过 4 个或要求非必填信息，提高咨询门槛
- ❌ 在锚点滚动时使用生硬的页面跳转，必须实现平滑滚动 (`scroll-behavior: smooth`)