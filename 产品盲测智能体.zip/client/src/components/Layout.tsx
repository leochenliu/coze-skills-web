import { useState, useEffect } from "react";
import { ActiveLink } from '@lark-apaas/client-toolkit/components/ActiveLink';
import { Outlet } from 'react-router-dom';
import { MenuIcon, XIcon, TargetIcon } from "lucide-react";
import { UniversalLink } from '@lark-apaas/client-toolkit/components/UniversalLink';

const NAV_ITEMS = [
  { label: "首页", anchor: "#hero" },
  { label: "核心能力", anchor: "#features" },
  { label: "客户案例", anchor: "#cases" },
];

const Layout = () => {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 10);
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  useEffect(() => {
    if (mobileOpen) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "";
    }
    return () => { document.body.style.overflow = ""; };
  }, [mobileOpen]);

  return (
    <div className="min-h-screen bg-background">
      {/* Topbar */}
      <header
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
          scrolled
            ? "bg-card/95 backdrop-blur-sm border-b border-border shadow-sm"
            : "bg-background"
        }`}
      >
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Brand */}
            <UniversalLink to="#hero" className="flex items-center gap-2 group">
              <div className="flex items-center justify-center w-8 h-8 rounded-lg bg-primary text-primary-foreground transition-transform group-hover:scale-105">
                <TargetIcon className="w-4 h-4" />
              </div>
              <span className="text-base font-semibold text-foreground">
                产品盲测技能
              </span>
            </UniversalLink>

            {/* Desktop Nav */}
            <nav className="hidden md:flex items-center gap-1">
              {NAV_ITEMS.map((item) => (
                <ActiveLink
                  key={item.anchor}
                  to={item.anchor}
                  onClick={() => setMobileOpen(false)}
                  className={({ isActive }) =>
                    `px-4 py-2 text-sm font-medium rounded-lg transition-colors ${
                      isActive
                        ? "bg-accent text-accent-foreground"
                        : "text-muted-foreground hover:text-foreground hover:bg-accent/50"
                    }`
                  }
                >
                  {item.label}
                </ActiveLink>
              ))}
            </nav>

            {/* Mobile Toggle */}
            <button
              className="md:hidden p-2 rounded-lg text-foreground hover:bg-accent transition-colors"
              onClick={() => setMobileOpen(!mobileOpen)}
              aria-label="切换导航菜单"
            >
              {mobileOpen ? (
                <XIcon className="w-5 h-5" />
              ) : (
                <MenuIcon className="w-5 h-5" />
              )}
            </button>
          </div>
        </div>
      </header>

      {/* Mobile Drawer */}
      {mobileOpen && (
        <div className="fixed inset-0 z-40 md:hidden">
          <div
            className="absolute inset-0 bg-black/20 backdrop-blur-sm"
            onClick={() => setMobileOpen(false)}
          />
          <div className="absolute top-16 left-0 right-0 bg-card border-b border-border shadow-lg">
            <nav className="max-w-6xl mx-auto px-4 py-4 space-y-1">
              {NAV_ITEMS.map((item) => (
                <ActiveLink
                  key={item.anchor}
                  to={item.anchor}
                  onClick={() => setMobileOpen(false)}
                  className={({ isActive }) =>
                    `block px-4 py-3 text-sm font-medium rounded-lg transition-colors ${
                      isActive
                        ? "bg-accent text-accent-foreground"
                        : "text-muted-foreground hover:text-foreground hover:bg-accent/50"
                    }`
                  }
                >
                  {item.label}
                </ActiveLink>
              ))}
            </nav>
          </div>
        </div>
      )}

      {/* Main Content */}
      <main className="pt-16">
        <Outlet />
      </main>
    </div>
  );
};

export default Layout;