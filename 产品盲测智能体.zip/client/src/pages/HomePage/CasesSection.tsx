import React from 'react';
import { TrendingDownIcon, TrendingUpIcon, ShieldCheckIcon, UsersIcon } from 'lucide-react';
import { motion } from 'framer-motion';

const metrics = [
  {
    label: '流失率降低',
    value: '40%',
    icon: TrendingDownIcon,
    description: '优化关键体验节点后',
  },
  {
    label: '上线前拦截',
    value: '12',
    unit: '个致命断点',
    icon: ShieldCheckIcon,
    description: '避免问题流入生产环境',
  },
  {
    label: '转化率提升',
    value: '25%',
    icon: TrendingUpIcon,
    description: '减少用户路径阻力',
  },
  {
    label: '覆盖用户样本',
    value: '6',
    unit: '类极端角色',
    icon: UsersIcon,
    description: '多维角色模拟测试',
  },
];

const testimonials = [
  {
    quote: '上线前发现了 3 个我们完全没意识到的体验断点，直接避免了上线后的用户流失。',
    author: '某 SaaS 产品负责人',
    role: '企业服务领域',
  },
  {
    quote: '以前靠熟人试用找问题，现在用系统化的方法提前发现风险，效率提升了不止一倍。',
    author: '某创业团队 CEO',
    role: '消费互联网',
  },
  {
    quote: '失败地图让我们清晰看到了用户在哪里放弃，优化方向一下变得非常明确。',
    author: '某电商平台产品总监',
    role: '电商零售',
  },
];

const container = {
  hidden: {},
  visible: {
    transition: { staggerChildren: 0.1, delayChildren: 0.15 },
  },
};

const item = {
  hidden: { opacity: 0, y: 24 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.5, ease: 'easeOut' as const } },
};

export default function CasesSection() {
  return (
    <section id="cases" className="w-full">
      <style jsx>{`
        .path-node {
          position: relative;
        }
        .path-node::after {
          content: '';
          position: absolute;
          right: -24px;
          top: 50%;
          transform: translateY(-50%);
          width: 16px;
          height: 2px;
          background: var(--border);
        }
        .path-node:last-child::after {
          display: none;
        }
        @media (max-width: 767px) {
          .path-node::after {
            display: none;
          }
        }
      `}</style>

      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-16 md:py-20">
        {/* Section Header */}
        <motion.div
          className="text-center mb-12 md:mb-16"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-80px' }}
          transition={{ duration: 0.5 }}
        >
          <span className="inline-block px-3 py-1 text-xs font-medium rounded-full bg-accent text-accent-foreground mb-4">
            客户案例
          </span>
          <h2 className="text-2xl md:text-3xl font-bold text-foreground tracking-tight">
            用数据验证价值
          </h2>
          <p className="mt-3 text-base text-muted-foreground max-w-lg mx-auto">
            通过构建产品失败地图，提前发现体验断点，降低流失并提升转化
          </p>
        </motion.div>

        {/* Metrics Grid */}
        <motion.div
          className="grid grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6 mb-12 md:mb-16"
          variants={container}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: '-60px' }}
        >
          {metrics.map((metric, index) => {
            const Icon = metric.icon;
            return (
              <motion.div
                key={index}
                variants={item}
                className="bg-card border border-border rounded-lg p-5 md:p-6 text-center hover:border-primary/30 transition-colors duration-200"
              >
                <div className="inline-flex items-center justify-center w-10 h-10 rounded-full bg-accent mb-3">
                  <Icon className="w-5 h-5 text-accent-foreground" />
                </div>
                <div className="flex items-baseline justify-center gap-1">
                  <span className="text-2xl md:text-3xl font-bold text-highlight">
                    {metric.value}
                  </span>
                  {metric.unit && (
                    <span className="text-sm text-muted-foreground">{metric.unit}</span>
                  )}
                </div>
                <p className="mt-1 text-sm font-medium text-foreground">{metric.label}</p>
                <p className="mt-1 text-xs text-muted-foreground">{metric.description}</p>
              </motion.div>
            );
          })}
        </motion.div>

        {/* Before/After Path Comparison */}
        <motion.div
          className="bg-card border border-border rounded-lg p-6 md:p-8 mb-12 md:mb-16"
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-60px' }}
          transition={{ duration: 0.5 }}
        >
          <h3 className="text-lg font-semibold text-foreground mb-6 text-center">
            优化前后 · 用户流失路径对比
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 md:gap-8">
            {/* Before */}
            <div className="space-y-4">
              <div className="flex items-center gap-2 mb-4">
                <span className="w-2 h-2 rounded-full bg-destructive" />
                <span className="text-sm font-medium text-muted-foreground">优化前</span>
              </div>
              <div className="space-y-3">
                {[
                  { label: '注册引导', status: 'confused', detail: '60% 用户在此放弃' },
                  { label: '核心功能', status: 'rage', detail: '操作路径混乱' },
                  { label: '付费转化', status: 'drop', detail: '价值感知不足' },
                ].map((step, i) => (
                  <div key={i} className="flex items-center gap-3">
                    <div className="w-20 shrink-0 text-xs text-muted-foreground text-right">
                      {step.label}
                    </div>
                    <div className="flex-1 h-8 bg-destructive/10 rounded-md border border-destructive/20 flex items-center px-3">
                      <span className="text-xs text-destructive">{step.detail}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* After */}
            <div className="space-y-4">
              <div className="flex items-center gap-2 mb-4">
                <span className="w-2 h-2 rounded-full bg-success" />
                <span className="text-sm font-medium text-muted-foreground">优化后</span>
              </div>
              <div className="space-y-3">
                {[
                  { label: '注册引导', status: 'clear', detail: '流失降至 15%' },
                  { label: '核心功能', status: 'clear', detail: '路径缩短 40%' },
                  { label: '付费转化', status: 'clear', detail: '转化提升 25%' },
                ].map((step, i) => (
                  <div key={i} className="flex items-center gap-3">
                    <div className="w-20 shrink-0 text-xs text-muted-foreground text-right">
                      {step.label}
                    </div>
                    <div className="flex-1 h-8 bg-success/10 rounded-md border border-success/20 flex items-center px-3">
                      <span className="text-xs text-success">{step.detail}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </motion.div>

        {/* Testimonials */}
        <motion.div
          className="grid grid-cols-1 md:grid-cols-3 gap-4 md:gap-6"
          variants={container}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: '-60px' }}
        >
          {testimonials.map((t, index) => (
            <motion.div
              key={index}
              variants={item}
              className="bg-card border border-border rounded-lg p-6 hover:border-primary/30 transition-colors duration-200"
            >
              <div className="mb-4">
                <svg
                  className="w-6 h-6 text-primary/30"
                  fill="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path d="M14.017 21v-7.391c0-5.704 3.731-9.57 8.983-10.609l.995 2.151c-2.432.917-3.995 3.638-3.995 5.849h4v10h-9.983zm-14.017 0v-7.391c0-5.704 3.748-9.57 9-10.609l.996 2.151c-2.433.917-3.996 3.638-3.996 5.849h3.983v10h-9.983z" />
                </svg>
              </div>
              <p className="text-sm text-foreground leading-relaxed mb-4">{t.quote}</p>
              <div className="pt-4 border-t border-border">
                <p className="text-sm font-medium text-foreground">{t.author}</p>
                <p className="text-xs text-muted-foreground mt-0.5">{t.role}</p>
              </div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
