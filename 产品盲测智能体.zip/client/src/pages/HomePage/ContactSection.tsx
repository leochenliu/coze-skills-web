import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { motion } from 'framer-motion';
import { SendIcon, CheckCircleIcon, Loader2Icon, ShieldCheckIcon } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { logger } from '@lark-apaas/client-toolkit/logger';

const contactSchema = z.object({
  name: z.string().min(1, '请输入您的姓名'),
  company: z.string().min(1, '请输入公司/产品名'),
  email: z.string().email('请输入有效的邮箱地址'),
  painPoint: z.string().min(1, '请描述您的核心痛点'),
});

type ContactFormData = z.infer<typeof contactSchema>;

const PAIN_POINT_OPTIONS = [
  { value: 'retention', label: '用户留存率低' },
  { value: 'conversion', label: '转化率不理想' },
  { value: 'feedback', label: '用户反馈少且模糊' },
  { value: 'optimization', label: '优化方向不明确' },
  { value: 'other', label: '其他问题' },
];

export default function ContactSection() {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);

  const form = useForm<ContactFormData>({
    resolver: zodResolver(contactSchema),
    defaultValues: {
      name: '',
      company: '',
      email: '',
      painPoint: '',
    },
  });

  const onSubmit = async (data: ContactFormData) => {
    setIsSubmitting(true);
    // 模拟提交延迟
    await new Promise((resolve) => setTimeout(resolve, 1500));
    logger.info('Contact form submitted:', String(data));
    setIsSubmitting(false);
    setIsSubmitted(true);
  };

  if (isSubmitted) {
    return (
      <section id="contact" className="w-full py-16 md:py-24">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.3 }}
            className="max-w-lg mx-auto bg-card border border-border rounded-lg p-8 text-center shadow-sm"
          >
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-success/10 mb-6">
              <CheckCircleIcon className="w-8 h-8 text-success" />
            </div>
            <h3 className="text-xl font-semibold text-foreground mb-3">已收到您的需求</h3>
            <p className="text-muted-foreground leading-relaxed">
              我们将在 24 小时内为您发送定制测评方案，请留意邮箱通知。
            </p>
          </motion.div>
        </div>
      </section>
    );
  }

  return (
    <section id="contact" className="w-full py-16 md:py-24">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-2xl mx-auto">
          {/* 区块标题 */}
          <div className="text-center mb-10">
            <h2 className="text-2xl md:text-3xl font-bold text-foreground mb-3">
              合作咨询
            </h2>
            <p className="text-muted-foreground text-base md:text-lg">
              填写以下信息，获取专属产品盲测方案
            </p>
          </div>

          {/* 表单容器 */}
          <div className="bg-card border border-border rounded-lg shadow-sm p-6 md:p-8">
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-5">
              {/* 姓名 */}
              <div className="space-y-2">
                <Label htmlFor="name" className="text-sm font-medium text-foreground">
                  姓名 <span className="text-destructive">*</span>
                </Label>
                <Input
                  id="name"
                  placeholder="请输入您的姓名"
                  className="h-10"
                  {...form.register('name')}
                />
                {form.formState.errors.name && (
                  <p className="text-sm text-destructive">{form.formState.errors.name.message}</p>
                )}
              </div>

              {/* 公司/产品名 */}
              <div className="space-y-2">
                <Label htmlFor="company" className="text-sm font-medium text-foreground">
                  公司/产品名 <span className="text-destructive">*</span>
                </Label>
                <Input
                  id="company"
                  placeholder="请输入公司或产品名称"
                  className="h-10"
                  {...form.register('company')}
                />
                {form.formState.errors.company && (
                  <p className="text-sm text-destructive">{form.formState.errors.company.message}</p>
                )}
              </div>

              {/* 联系邮箱 */}
              <div className="space-y-2">
                <Label htmlFor="email" className="text-sm font-medium text-foreground">
                  联系邮箱 <span className="text-destructive">*</span>
                </Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="请输入邮箱地址"
                  className="h-10"
                  {...form.register('email')}
                />
                {form.formState.errors.email && (
                  <p className="text-sm text-destructive">{form.formState.errors.email.message}</p>
                )}
              </div>

              {/* 核心痛点 */}
              <div className="space-y-2">
                <Label htmlFor="painPoint" className="text-sm font-medium text-foreground">
                  当前核心痛点 <span className="text-destructive">*</span>
                </Label>
                <Select
                  onValueChange={(value) => form.setValue('painPoint', value, { shouldValidate: true })}
                >
                  <SelectTrigger className="h-10">
                    <SelectValue placeholder="请选择您面临的核心问题" />
                  </SelectTrigger>
                  <SelectContent>
                    {PAIN_POINT_OPTIONS.map((option) => (
                      <SelectItem key={option.value} value={option.value}>
                        {option.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {form.formState.errors.painPoint && (
                  <p className="text-sm text-destructive">{form.formState.errors.painPoint.message}</p>
                )}
              </div>

              {/* 补充说明（可选） */}
              <div className="space-y-2">
                <Label htmlFor="description" className="text-sm font-medium text-foreground">
                  补充说明
                </Label>
                <Textarea
                  id="description"
                  placeholder="简要描述您的产品现状或具体需求（选填）"
                  className="min-h-[100px] resize-none"
                />
              </div>

              {/* 提交按钮 */}
              <Button
                type="submit"
                disabled={isSubmitting}
                className="w-full h-11 text-base font-medium"
              >
                {isSubmitting ? (
                  <>
                    <Loader2Icon className="w-4 h-4 mr-2 animate-spin" />
                    提交中...
                  </>
                ) : (
                  <>
                    <SendIcon className="w-4 h-4 mr-2" />
                    提交咨询
                  </>
                )}
              </Button>
            </form>

            {/* 隐私声明 */}
            <div className="mt-6 pt-5 border-t border-border flex items-start gap-2">
              <ShieldCheckIcon className="w-4 h-4 text-muted-foreground mt-0.5 shrink-0" />
              <p className="text-xs text-muted-foreground leading-relaxed">
                您提交的信息仅用于合作咨询，我们将严格保密，不会用于任何其他用途。
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
