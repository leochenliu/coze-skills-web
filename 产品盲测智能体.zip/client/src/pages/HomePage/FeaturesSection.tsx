import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { UsersIcon, TargetIcon, MapIcon, ShieldIcon, XCircleIcon, CheckCircleIcon } from 'lucide-react';

interface IFeatureCard {
  id: string;
  icon: React.ReactNode;
  step: string;
  title: string;
  description: string;
  details: string[];
  borderColor: string;
}

const featureCards: IFeatureCard[] = [
  {
    id: 'role-simulation',
    icon: <UsersIcon className="w-6 h-6" />,
    step: '第一步',
    title: '多维角色模拟',
    description: '不再用"正常用户"测试，组合职业/年龄/认知三大维度，生成最容易把产品用崩的用户组合',
    details: [
      '职业维度：工人 / 程序员 / 老板 / 学生',
      '年龄维度：年轻 / 中年 / 老年',
      '认知维度：小白 / 半懂 / 专业',
      '输出：高风险用户画像组合'
    ],
    borderColor: 'border-l-primary'
  },
  {
    id: 'extreme-samples',
    icon: <TargetIcon className="w-6 h-6" />,
    step: '第二步',
    title: '极端样本优先',
    description: '优先测试"最危险的人"——不是平均用户，而是最容易流失的四类关键用户',
    details: [
      '最不懂的人 → 测引导清晰度',
      '最挑剔的人 → 测功能完整性',
      '最没耐心的人 → 测流程简洁度',
      '最价格敏感的人 → 测价值感知'
    ],
    borderColor: 'border-l-primary'
  },
  {
    id: 'failure-map',
    icon: <MapIcon className="w-6 h-6" />,
    step: '第三步',
    title: '失败地图构建',
    description: '精准识别用户流失的关键节点，输出完整的用户流失路径图',
    details: [
      'Drop-off Peak：流失最高点',
      'Misunderstanding Zone：理解错误点',
      'Rage Point：情绪爆炸点',
      '输出：完整用户流失路径'
    ],
    borderColor: 'border-l-primary'
  },
  {
    id: 'adversarial-test',
    icon: <ShieldIcon className="w-6 h-6" />,
    step: '第四步',
    title: '对抗测试机制',
    description: '主动"攻击你的产品"，模拟真实破坏行为，测试产品如何崩溃而非正常使用',
    details: [
      '输入攻击：异常数据注入',
      '流程破坏：跳步骤操作',
      '极限操作：狂点、重复提交',
      '异常环境：断网、权限拒绝'
    ],
    borderColor: 'border-l-primary'
  }
];

const traditionalVsBlindTest = [
  { traditional: '找熟人试用（太友好，不真实）', blind: '模拟真实陌生用户行为' },
  { traditional: '只看功能是否正常', blind: '关注用户体验与情绪断点' },
  { traditional: '不模拟极端用户', blind: '优先测试最危险用户群体' },
  { traditional: '出问题再修（成本成倍增加）', blind: '上线前发现并解决致命问题' }
];

const FeatureCard: React.FC<{ card: IFeatureCard }> = ({ card }) => {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <motion.div
      className={`bg-card border border-border rounded-lg shadow-sm border-l-4 ${card.borderColor} p-6 cursor-pointer transition-all duration-200`}
      onHoverStart={() => setIsHovered(true)}
      onHoverEnd={() => setIsHovered(false)}
      whileHover={{ y: -4, boxShadow: '0 12px 24px -8px hsl(221 83% 53% / 0.15)' }}
      transition={{ duration: 0.2 }}
    >
      <div className="flex items-start gap-4">
        <div className="flex-shrink-0 w-12 h-12 rounded-lg bg-accent flex items-center justify-center text-accent-foreground">
          {card.icon}
        </div>
        <div className="flex-1 min-w-0">
          <span className="text-xs font-medium text-muted-foreground uppercase tracking-wide">{card.step}</span>
          <h3 className="text-lg font-semibold text-foreground mt-1">{card.title}</h3>
          <p className="text-sm text-muted-foreground mt-2 leading-relaxed">{card.description}</p>
        </div>
      </div>

      <motion.div
        initial={false}
        animate={{ height: isHovered ? 'auto' : 0, opacity: isHovered ? 1 : 0 }}
        transition={{ duration: 0.2 }}
        className="overflow-hidden"
      >
        <div className="pt-4 mt-4 border-t border-border">
          <ul className="space-y-2">
            {card.details.map((detail, index) => (
              <li key={index} className="text-sm text-foreground flex items-start gap-2">
                <span className="text-primary mt-0.5">→</span>
                <span>{detail}</span>
              </li>
            ))}
          </ul>
        </div>
      </motion.div>
    </motion.div>
  );
};

const FeaturesSection: React.FC = () => {
  return (
    <section className="w-full" id="features">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        {/* 区块标题 */}
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-foreground">
            构建<span className="text-primary">产品失败地图</span>的四步法
          </h2>
          <p className="text-lg text-muted-foreground mt-4 max-w-2xl mx-auto">
            不是测试功能是否正常，而是系统性证明产品会死在哪里
          </p>
        </div>

        {/* 四步法卡片网格 */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-16">
          {featureCards.map((card) => (
            <FeatureCard key={card.id} card={card} />
          ))}
        </div>

        {/* 传统测试 vs 盲测对比 */}
        <div className="bg-card border border-border rounded-lg p-8">
          <h3 className="text-xl font-semibold text-foreground mb-6 text-center">
            传统测试 <span className="text-muted-foreground font-normal">vs</span> 产品盲测
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* 传统测试 */}
            <div>
              <div className="flex items-center gap-2 mb-4">
                <XCircleIcon className="w-5 h-5 text-destructive" />
                <h4 className="font-semibold text-foreground">传统产品测试</h4>
              </div>
              <ul className="space-y-3">
                {traditionalVsBlindTest.map((item, index) => (
                  <li key={index} className="text-sm text-muted-foreground flex items-start gap-2">
                    <span className="text-destructive mt-0.5">✕</span>
                    <span>{item.traditional}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* 产品盲测 */}
            <div>
              <div className="flex items-center gap-2 mb-4">
                <CheckCircleIcon className="w-5 h-5 text-success" />
                <h4 className="font-semibold text-foreground">产品盲测技能</h4>
              </div>
              <ul className="space-y-3">
                {traditionalVsBlindTest.map((item, index) => (
                  <li key={index} className="text-sm text-foreground flex items-start gap-2">
                    <span className="text-success mt-0.5">✓</span>
                    <span>{item.blind}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default FeaturesSection;
