import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { ArrowDownIcon, ChevronRightIcon, TargetIcon, TrendingDownIcon, MessageSquareOffIcon, WrenchIcon } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { UniversalLink } from '@lark-apaas/client-toolkit/components/UniversalLink';

const painPoints = [
  { icon: TrendingDownIcon, text: '产品上线了，但用户就是留不住' },
  { icon: TargetIcon, text: '功能做得很全，但转化很低' },
  { icon: MessageSquareOffIcon, text: '用户反馈很少，但数据在掉' },
  { icon: WrenchIcon, text: '每次优化一点，但整体没改善' },
];

export default function HeroSection() {
  const [activeIndex, setActiveIndex] = useState(0);

  const scrollToSection = (id: string) => {
    const el = document.querySelector(id);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  useEffect(() => {
    const timer = setInterval(() => {
      setActiveIndex((prev) => (prev + 1) % painPoints.length);
    }, 3000);
    return () => clearInterval(timer);
  }, []);

  const ActiveIcon = painPoints[activeIndex].icon;

  return (
    <section className="w-full" id="hero">
      <style jsx>{`
        .hero-gradient {
          background: radial-gradient(ellipse 80% 60% at 50% 0%, hsl(221 83% 96% / 0.6) 0%, transparent 70%);
        }
      `}</style>

      <div className="hero-gradient">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 pt-24 pb-20 md:pt-32 md:pb-28">
          {/* 主标题区 */}
          <motion.div
            className="text-center max-w-3xl mx-auto"
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, ease: 'easeOut' }}
          >
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-accent text-accent-foreground text-sm font-medium mb-6">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75" />
                <span className="relative inline-flex rounded-full h-2 w-2 bg-primary" />
              </span>
              产品盲测技能 v1.5
            </div>

            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-foreground tracking-tight leading-tight">
              你以为产品没问题，
              <br />
              <span className="text-primary">其实它早就注定会失败</span>
            </h1>

            <p className="mt-6 text-lg md:text-xl text-muted-foreground leading-relaxed max-w-2xl mx-auto">
              你缺的不是更多测试，而是一套能系统性证明<span className="text-foreground font-medium">"产品会死在哪里"</span>的方法
            </p>
          </motion.div>

          {/* 痛点轮播区 */}
          <motion.div
            className="mt-12 max-w-xl mx-auto"
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2, ease: 'easeOut' }}
          >
            <div className="bg-card border border-border rounded-lg p-5 shadow-sm">
              <div className="flex items-start gap-3">
                <div className="flex-shrink-0 w-10 h-10 rounded-lg bg-destructive/10 flex items-center justify-center">
                  <ActiveIcon className="w-5 h-5 text-destructive" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm text-muted-foreground mb-1">你有没有这种情况</p>
                  <p className="text-foreground font-medium transition-all duration-300">
                    {painPoints[activeIndex].text}
                  </p>
                </div>
              </div>
              {/* 进度指示器 */}
              <div className="mt-4 flex gap-1.5">
                {painPoints.map((_, i) => (
                  <div
                    key={i}
                    className={`h-1 rounded-full transition-all duration-500 ${
                      i === activeIndex ? 'flex-1 bg-primary' : 'flex-1 bg-border'
                    }`}
                  />
                ))}
              </div>
            </div>
          </motion.div>

          {/* CTA 按钮组 */}
          <motion.div
            className="mt-10 flex flex-col sm:flex-row items-center justify-center gap-4"
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.4, ease: 'easeOut' }}
          >
            <UniversalLink
              to="https://www.coze.cn/skills?skill_share_pid=7623689867368906804"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center justify-center gap-2 whitespace-nowrap font-medium rounded-lg shadow-sm h-12 px-8 text-base bg-primary text-primary-foreground border border-primary-border hover:bg-primary/90 transition-colors"
            >
              立即获取测评报告
              <ChevronRightIcon className="w-4 h-4" />
            </UniversalLink>
            <Button
              variant="outline"
              size="lg"
              className="h-12 px-8 text-base rounded-lg"
              onClick={() => scrollToSection('#features')}
            >
              了解工作原理
              <ArrowDownIcon className="w-4 h-4 ml-1" />
            </Button>
          </motion.div>

          {/* 底部提示 */}
          <motion.p
            className="mt-12 text-center text-sm text-muted-foreground"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5, delay: 0.6 }}
          >
            问题从来不在流量，而在你有没有构建一张完整的<span className="text-foreground font-medium">产品失败地图</span>
          </motion.p>
        </div>
      </div>
    </section>
  );
}
