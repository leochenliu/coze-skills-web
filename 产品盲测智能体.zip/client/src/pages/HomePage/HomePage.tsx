import React from 'react';
import HeroSection from './HeroSection';
import FeaturesSection from './FeaturesSection';
import CasesSection from './CasesSection';

const HomePage: React.FC = () => {
  return (
    <div className="w-full space-y-0">
      <section className="w-full">
        <HeroSection />
      </section>
      <section className="w-full">
        <FeaturesSection />
      </section>
      <section className="w-full">
        <CasesSection />
      </section>
    </div>
  );
};

export default HomePage;
